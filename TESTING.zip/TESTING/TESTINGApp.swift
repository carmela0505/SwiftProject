//
//  TESTINGApp.swift
//  TESTING
//
//  Created by apprenant130 on 13/09/2025.
//

import SwiftUI

@main
struct TESTINGApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
