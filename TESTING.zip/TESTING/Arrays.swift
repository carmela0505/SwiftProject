//
//  Arrays.swift
//  TESTING
//
//  Created by apprenant130 on 14/09/2025.
//

import SwiftUI



public struct Arrays: View {
    
    let animals = ["🐶", "🐱", "🐭", "🐹", "🐰", "🐻", "🐼", "🐨", "🐵", "🐿️"]
    
    var prefixedAnimals: [String] {
        animals.enumerated().map(\.1)
    }
    
    
    
    public var body: some View {
        VStack {
            HStack{
                ForEach(prefixedAnimals, id: \.self) { animal in
                    Text(animal)
                }
            }
            Text("Arrays")
        }
    }
}

#Preview {
    Arrays()
    
}
