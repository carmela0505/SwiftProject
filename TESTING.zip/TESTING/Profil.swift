//
//  Profil.swift
//  TESTING
//
//  Created by apprenant130 on 14/09/2025.
//
import SwiftUI

extension Binding where Value == String {
    func nameCased() -> Binding<String> {
        Binding(
            get: { self.wrappedValue },
            set: { new in
                let lower = new.lowercased()
                if let first = lower.first {
                    self.wrappedValue = String(first).uppercased() + lower.dropFirst()
                } else {
                    self.wrappedValue = ""
                }
            }
        )
    }
    func lowercasedInput() -> Binding<String> {
        Binding(
            get: { self.wrappedValue },
            set: { new in self.wrappedValue = new.lowercased() }
        )
    }
}

extension View {
    func cardStyle() -> some View {
        self
            .padding(14)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .shadow(color: .black.opacity(0.06), radius: 8, x: 0, y: 2)
            .listRowBackground(Color.clear) // keep the section row transparent over our custom bg
    }
}

struct ProfilParentFormView: View {
    // Champs
    @State private var nom = ""
    @State private var prenom = ""
    @State private var prenomEnfant = ""
    @State private var email = ""
    @State private var dateNaissance = Date()
    @State private var relation = "Mère"

    // UI
    @State private var showAlert = false
    @State private var alertMessage = ""

    @FocusState private var focus: Champ?
    enum Champ: Hashable { case nom, prenom, prenomEnfant, email }

    private let relations = ["Mère", "Père", "Tuteur·trice"]

    // Validation
    private func isValidName(_ s: String) -> Bool {
        s.trimmingCharacters(in: .whitespacesAndNewlines).count >= 3
    }
    private func normalizeEmail(_ input: String) -> String {
        input.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    }
    private func isValidEmail(_ input: String) -> Bool {
        let mail = normalizeEmail(input)
        let regex = #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#
        return mail.range(of: regex, options: [.regularExpression, .caseInsensitive]) != nil
    }
    private var formOK: Bool {
        isValidName(nom) && isValidName(prenom) && isValidName(prenomEnfant) && isValidEmail(email)
    }

    // Orange
    private var Orange: Color { Color.orange.opacity(0.8) }

    var body: some View {
        NavigationStack {
            ZStack {
                Orange.ignoresSafeArea()

                Form {
                    
                    Section {
                        VStack(spacing: 12) {
                            TextField("Nom", text: $nom.nameCased())
                                .textInputAutocapitalization(.words)
                                .autocorrectionDisabled()
                                .focused($focus, equals: .nom)
                                .submitLabel(.next)
                                .padding(.horizontal, 12)
                                   .padding(.vertical, 10)
                                   .background(Color.blue.opacity(0.2))
                                   .overlay(
                                       RoundedRectangle(cornerRadius: 12, style: .continuous)
                                           .stroke(Color.gray.opacity(0.35), lineWidth: 1)
                                   )
                                   .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                            if !nom.isEmpty && !isValidName(nom) {
                                Text("Le nom doit contenir au moins 3 caractères.")
                                    .font(.caption).foregroundColor(.red)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }

                            TextField("Prénom", text: $prenom.nameCased())
                                .textInputAutocapitalization(.words)
                                .autocorrectionDisabled()
                                .focused($focus, equals: .prenom)
                                .submitLabel(.next)
                                .padding(.horizontal, 12)
                                   .padding(.vertical, 12)
                                   .background(Color.blue.opacity(0.2))
                                   .overlay(
                                       RoundedRectangle(cornerRadius: 12, style: .continuous)
                                           .stroke(Color.gray.opacity(0.35), lineWidth: 1)
                                   )
                                   .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))

                            if !prenom.isEmpty && !isValidName(prenom) {
                                Text("Le prénom doit contenir au moins 3 caractères.")
                                    .font(.caption).foregroundColor(.red)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }

                            DatePicker("Date de naissance",
                                       selection: $dateNaissance,
                                       in: ...Date(),
                                       displayedComponents: .date)

                            Picker("Relation", selection: $relation) {
                                ForEach(relations, id: \.self) { Text($0) }
                            }
                            .pickerStyle(.segmented)
                        }
                        .cardStyle()
                    } header: {
                        Text("Identité du parent")
                            .font(.headline)
                            .textCase(nil) // keep original casing
                    }

                    Section {
                        VStack(spacing: 12) {
                            TextField("Prénom de l’enfant", text: $prenomEnfant.nameCased())
                                .textInputAutocapitalization(.words)
                                .autocorrectionDisabled()
                                .focused($focus, equals: .prenomEnfant)
                                .submitLabel(.next)

                            if !prenomEnfant.isEmpty && !isValidName(prenomEnfant) {
                                Text("Le prénom de l’enfant doit contenir au moins 3 caractères.")
                                    .font(.caption).foregroundColor(.red)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                        .cardStyle()
                    } header: {
                        Text("Enfant")
                            .font(.headline).textCase(nil)
                    }

                    Section {
                        VStack(spacing: 12) {
                            TextField("Email", text: $email.lowercasedInput())
                                .keyboardType(.emailAddress)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()
                                .focused($focus, equals: .email)
                                .submitLabel(.done)

                            if !email.isEmpty && !isValidEmail(email) {
                                Text("Email invalide.")
                                    .font(.caption).foregroundColor(.red)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                            }
                        }
                        .cardStyle()
                    } header: {
                        Text("Email")
                            .font(.headline).textCase(nil)
                    }

                    Section {
                        NavigationLink {
                            ProfileEnfant(prenomEnfant: prenomEnfant)
                        } label: {
                            Text("Continuer vers le profil enfant")
                                .frame(maxWidth: .infinity)
                                .font(.system(size: 18, weight: .bold, design: .rounded))
                        }
                        .buttonStyle(.borderedProminent)
                        .buttonBorderShape(.roundedRectangle(radius: 14))
                        .tint(.blue)
                        .disabled(!formOK)
                    } footer: {
                        Text("Les prénoms doivent commencer par une majuscule et faire au moins 3 caractères.")
                    }
                    .listRowBackground(Color.clear)
                }
                .scrollContentBackground(.hidden)
            }
            .navigationTitle("Profil parent")
            .navigationBarTitleDisplayMode(.inline)
            .onSubmit {
                switch focus {
                case .nom:          focus = .prenom
                case .prenom:       focus = .prenomEnfant
                case .prenomEnfant: focus = .email
                default:            focus = nil
                }
            }
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Terminé") { focus = nil }
                }
            }
            .alert("Information", isPresented: $showAlert) {
                Button("OK", role: .cancel) { }
            } message: {
                Text(alertMessage)
            }
        }
    }
}

#Preview {
    NavigationStack { ProfilParentFormView() }
}
