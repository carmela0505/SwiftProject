//
//  ProfilEnfant.swift
//  TESTING
//
//  Created by apprenant130 on 17/09/2025.
//
import SwiftUI

struct ProfileEnfant: View {
    let prenomEnfant: String
   @State private var mascotName: String = "mascottedog"
    private let choices = ["mascottedog", "mascotracoon", "mascotteduck", "mascotdonkey"]

    var body: some View {
        ZStack {
            Image("yellow")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("PROFIL ENFANT")
                    .font(.system(size: 46, weight: .bold, design: .rounded))
                    .foregroundColor(.pink)

                Divider()
                Spacer()

                Text("Bienvenue \(prenomEnfant)")
                    .font(.system(size: 35, weight: .bold, design: .rounded))

                LottieView(name: mascotName, contentMode: .scaleAspectFill)
                    .frame(width: 300, height: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .overlay(RoundedRectangle(cornerRadius: 20).stroke(.white, lineWidth: 4))
                    .shadow(radius: 10)

                Spacer()

              
                NavigationLink {
                    BackgroundColorAttribute()
                } label: {
                    Text("JOUER")
                        .font(.system(size: 28, weight: .bold))
                        .padding(.horizontal, 60)
                        .padding(.vertical, 20)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 25))
                        .shadow(radius: 6)
                }

                // Mascot chooser
                Menu {
                    ForEach(choices, id: \.self) { option in
                        Button(option) { mascotName = option }
                    }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: "figure.2.and.child.holdinghands")
                        Text("Changer de mascotte")
                    }
                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                    .frame(width: 300, height: 56)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
                    .shadow(radius: 4)
                }
                .controlSize(.large)
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

#Preview {
    NavigationStack { ProfileEnfant(prenomEnfant: "Léa") }
}
