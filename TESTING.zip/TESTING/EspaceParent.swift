//
//  EspaceParent.swift
//  TESTING
//
//  Created by apprenant130 on 18/09/2025.
//

import SwiftUI

struct EspaceParent: View {
    var body: some View {
        Text("EspaceParent")
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
#Preview {
    EspaceParent()
}
