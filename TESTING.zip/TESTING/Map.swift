//
//  Map.swift
//  TESTING
//
//  Created by apprenant130 on 18/09/2025.
//


import SwiftUI

private let nodePrimary = Color(red: 0.05, green: 0.16, blue: 0.44) // dark blue

struct Level: Identifiable, Hashable {
    let id: Int
    let title: String
    var isLocked: Bool
    var progress: Double // 0.0 ... 1.0
    
}

func makeLevels(for theme: Theme) -> [Level] {
    // Example: first 2 unlocked, next locked; tweak to your logic
    (1...12).map { i in
        Level(
            id: i,
            title: "Niveau \(i)",
            isLocked: i > 2,                // only first 2 unlocked
            progress: i == 1 ? 1.0 : 0.0    // level 1 complete, others 0
        )
    }
}

struct LevelNode: View {
    let level: Level
    let theme: Theme

    var body: some View {
        ZStack {
            // progress ring
            Circle()
                .stroke(nodePrimary.opacity(0.25), lineWidth: 8)
                .frame(width: 72, height: 72)
            Circle()
                .trim(from: 0, to: min(max(level.progress, 0), 1))
                .stroke(nodePrimary, style: StrokeStyle(lineWidth: 8, lineCap: .round))
                .rotationEffect(.degrees(-90))
                .frame(width: 72, height: 72)
                .opacity(level.progress > 0 ? 1 : 0.2)

            // center content
            if level.isLocked {
                Image(systemName: "lock.fill")
                    .font(.title3.bold())
                    .foregroundStyle(nodePrimary)
            } else if level.progress >= 1 {
                Image(systemName: "checkmark")
                    .font(.title3.bold())
                    .foregroundStyle(nodePrimary)
            } else {
                Text("\(level.id)")
                    .font(.title3.bold())
                    .foregroundStyle(nodePrimary)
            }
        }
        .padding(6)
        .background(.white.opacity(0.08), in: Circle())
        .overlay(Circle().strokeBorder(nodePrimary.opacity(0.15), lineWidth: 1))
        .opacity(level.isLocked ? 0.6 : 1.0)
        .accessibilityLabel("\(level.title) \(level.isLocked ? "verrouillé" : "")")
    }
}

struct MapConnector: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 2, style: .continuous)
            .fill(nodePrimary.opacity(0.25))
            .frame(width: 4, height: 36)
    }
}

struct ThemeMapView: View {
    let theme: Theme
    @State private var levels: [Level]

    init(theme: Theme) {
        self.theme = theme
        _levels = State(initialValue: makeLevels(for: theme))
    }

    var body: some View {
        ZStack {
            Image("mapblue")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
           
            theme.gradient
                        .opacity(0.25)
                        .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 12) {
                    header
                    map
                }
                .padding(.vertical, 16)
            }
        }
        .navigationTitle(theme.title)
        .navigationBarTitleDisplayMode(.inline)
    }

    private var header: some View {
        VStack(spacing: 8) {
            Image(systemName: theme.symbol)
                .font(.system(size: 48, weight: .bold))
                .foregroundStyle(.blue)
                .padding(14)
                .background(.white.opacity(0.15), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            Text(theme.subtitle)
                .foregroundStyle(.black.opacity(0.95))
        }
        .padding(.bottom, 8)
    }
    private let nodeHorizontalOffset: CGFloat = 80
    private var map: some View {
        VStack(spacing: 0) {
            ForEach(levels.indices, id: \.self) { idx in
                let level = levels[idx]
                let sideOffset = idx.isMultiple(of: 2) ? -nodeHorizontalOffset : nodeHorizontalOffset

                ZStack {
                    
                    if level.isLocked {
                        LevelNode(level: level, theme: theme)
                            .padding(.horizontal, 24)
                    } else {
                        NavigationLink {
                            LevelDetailView(theme: theme, level: level)
                        } label: {
                            LevelNode(level: level, theme: theme)
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal, 24)
                    }
                    if !idx.isMultiple(of: 2) { Spacer() }
                }
                .padding(.vertical, 10)

                if idx < levels.count - 1 {
                    MapConnector()
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                }
            }
            .padding(.bottom, 24)
        }
    }
}



struct LevelDetailView: View {
    let theme: Theme
    let level: Level

    var body: some View {
        ZStack {
            
            theme.gradient.ignoresSafeArea()
            VStack(spacing: 16) {
                Text(level.title).font(.largeTitle.bold()).foregroundStyle(.white)
                Text("Contenu du niveau pour « \(theme.title) ».\nIci: leçon, quiz, mini-jeu, etc.")
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.white.opacity(0.95))
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}
private let previewTheme = Theme(
    id: .ecole,
    title: "À l’école",
    subtitle: "Respect, harcèlement, entraide",
    symbol: "graduationcap.fill"
)

// Full map preview (with navigation for level links)
#Preview("Map – École") {
    NavigationStack {
        ThemeMapView(theme: previewTheme)
    }
}

// Single node – unlocked/in progress
#Preview("Level Node – Unlocked") {
    ZStack {
        previewTheme.gradient.ignoresSafeArea()
        LevelNode(
            level: Level(id: 1, title: "Niveau 1", isLocked: false, progress: 0.4),
            theme: previewTheme
        )
    }
    .frame(height: 140)
}

// Single node – locked
#Preview("Level Node – Locked") {
    ZStack {
        previewTheme.gradient.ignoresSafeArea()
        LevelNode(
            level: Level(id: 2, title: "Niveau 2", isLocked: true, progress: 0.0),
            theme: previewTheme
        )
    }
    .frame(height: 140)
}

// Level detail preview
#Preview("Level Detail") {
    NavigationStack {
        LevelDetailView(
            theme: previewTheme,
            level: Level(id: 1, title: "Niveau 1", isLocked: false, progress: 1.0)
        )
    }
}
    
       


